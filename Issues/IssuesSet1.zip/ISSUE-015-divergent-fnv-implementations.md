# [ISSUE-015] Two divergent FNV-1a hash implementations

| | |
|---|---|
| **Severity** | Low |
| **Type** | Consistency / maintainability |
| **Component** | Generator (DictionaryConverter / GeneratedNames) |
| **Finding ID** | B03-3 |
| **Affects** | `src/DwarfMapper.Generator/**` |

## Where
Two separate FNV-1a implementations exist (e.g. `GeneratedNames.cs:52` and the `MapToGenerator.Hash` at
`MapToGenerator.cs:250-263`, plus any hashing in `DictionaryConverter`). They compute helper/field names independently.

## What
The generator hashes strings (type keys, member paths) to build stable synthesized-helper and field names, but does so
via more than one copy of FNV-1a. The copies can drift (different seeds/primes/output formatting), and duplicated logic
is a maintenance hazard.

## Why it matters
No current correctness bug, but: (1) if two copies ever diverge, cross-referencing helper names between subsystems could
break; (2) it is duplicated logic that invites subtle inconsistency; (3) any future collision-hardening (see ISSUE-007)
must be applied in multiple places.

## Reproduction
Static — grep for the FNV constant `16777619` / `2166136261` across the generator.

## Proposed fix
Extract a single internal `StableHash.Fnv1a(string) : string` (or `uint`) helper and route every call site through it.
Assert the output format (e.g. lowercase 8-hex) once.

## Regression test
```csharp
[Fact]
public void All_call_sites_use_the_shared_stable_hash()
{
    // Guard: exactly one FNV constant occurrence in the generator (in StableHash), enforced by a source-scan test.
    var occurrences = CountOccurrencesInGeneratorSource("16777619");
    Assert.Equal(1, occurrences);
}
```
Plus a value test pinning the hash of a few known inputs (so a future refactor can't silently change generated names).
