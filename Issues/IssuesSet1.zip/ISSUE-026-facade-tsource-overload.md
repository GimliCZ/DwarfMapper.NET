# [ISSUE-026] `DwarfMapperFacade.Map<TSource,TDestination>` ignores `TSource` (documentation/behaviour mismatch)

| | |
|---|---|
| **Severity** | Medium |
| **Type** | API — doc/impl mismatch + latent semantic surprise |
| **Component** | Runtime / IDwarfMapper |
| **Finding ID** | B15-1 |
| **Affects** | `src/DwarfMapper/IDwarfMapper.cs` |

## Where
`IDwarfMapper.cs` — `DwarfMapperFacade.Map<TSource, TDestination>(TSource source)`:

```csharp
public TDestination Map<TSource, TDestination>(TSource source)
{
    return (TDestination)DwarfMapperRegistry.Map(source!, typeof(TDestination));
}
```
The interface doc states this overload maps "using the **static source type** — avoids the `GetType()` hop when the
source type is known."

## What
The body is byte-identical to the single-type-parameter `Map<TDestination>(object)` overload: it calls
`DwarfMapperRegistry.Map(source!, typeof(TDestination))`, which resolves by `source.GetType()` (runtime type) plus a
base-type walk. `TSource` is never used. So:
1. the documented `GetType()`-hop avoidance is **not implemented**; and
2. a `Map<Base, Dto>(derivedInstance)` call resolves by the **derived** runtime type's map, not `Base`'s — contradicting
   the "static source type" contract.

## Why it matters
- The performance claim in the docs is false.
- The semantic contract is misleading: a caller who deliberately types the source as `Base` to select `Base`'s map gets
  the derived map instead. This is a quiet behavioural surprise for polymorphic sources.

## Reproduction
```csharp
DwarfMapperRegistry.Register(typeof(Base),    typeof(Dto), s => MapBase((Base)s));
DwarfMapperRegistry.Register(typeof(Derived), typeof(Dto), s => MapDerived((Derived)s));

Base b = new Derived();
var dto = DwarfMapperFacade.Instance.Map<Base, Dto>(b);
// Documented: uses Base's map. Actual: uses Derived's map (resolved via b.GetType()).
```

## Proposed fix
Choose one:

**(a) Implement the fast path (honour the doc).** Add a registry lookup by the *static* type and use it:
```csharp
public TDestination Map<TSource, TDestination>(TSource source)
{
    if (DwarfMapperRegistry.TryGet(typeof(TSource), typeof(TDestination), out var map) && map is not null)
        return (TDestination)map(source!);
    return (TDestination)DwarfMapperRegistry.Map(source!, typeof(TDestination)); // fallback to runtime-type walk
}
```

**(b) Fix the documentation** to state that resolution is always by runtime type, and that the two-parameter overload
is a typing convenience only (no perf/semantic difference).

Prefer (a): it makes the overload meaningful and matches the stated contract; keep the runtime-type fallback for when no
exact `TSource` map is registered.

## Regression test
```csharp
[Fact]
public void Facade_two_param_overload_uses_static_source_type()
{
    DwarfMapperRegistry.ResetForTests();
    DwarfMapperRegistry.Register(typeof(Base),    typeof(Dto), s => new Dto { Tag = "base" });
    DwarfMapperRegistry.Register(typeof(Derived), typeof(Dto), s => new Dto { Tag = "derived" });

    Base b = new Derived();
    var dto = DwarfMapperFacade.Instance.Map<Base, Dto>(b);
    Assert.Equal("base", dto.Tag);   // fix (a): resolves by TSource
}
```
Fails today (`"derived"`); passes after fix (a). If (b) is chosen instead, replace with a doc test / assert the
documented runtime-type behaviour explicitly.

## Notes
- `DwarfMapperRegistry.TryGet` already exists (exact-pair lookup, no base walk) — fix (a) is a few lines.
