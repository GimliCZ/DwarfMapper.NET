# [ISSUE-027] Extractor couples to enum option values via magic integers

| | |
|---|---|
| **Severity** | Low |
| **Type** | Latent fragility |
| **Component** | Generator / Extractor |
| **Finding ID** | B16-N |
| **Affects** | `src/DwarfMapper.Generator/Pipeline/MapperExtractor.cs`, `src/DwarfMapper/*Strategy.cs` |

## Where
`MapperExtractor.cs:174,179` and the enum option readers:
```csharp
var isPreserveMode = referenceHandling == 1; // 1 = ReferenceHandlingStrategy.Preserve
var isSetNullMode  = onCycle == 1 && !isPreserveMode;
// similarly: nameConvention == 1 (Flexible), requiredMapping == 1 (Both), etc.
```

## What
Enum-typed options are read from attribute data as their underlying `int` and compared against hardcoded literals
(`== 1`, `== 2`) rather than against the named enum members. Verified all current values match
(`ReferenceHandlingStrategy.Preserve == 1`, `OnCycleStrategy.SetNull == 1`, `NameConvention.Flexible == 1`,
`RequiredMappingStrategy.Both == 1`).

## Why it matters
Currently correct, but fragile: reordering or inserting an enum member in the runtime `*Strategy` enums would silently
desync the extractor's magic-int comparisons with **no compile error** — the generator would misread the option and
change behaviour. Enum reordering is itself a breaking change, so risk is low, but the coupling is invisible and
unguarded.

## Reproduction
Static. Demonstrable by inserting a member at the front of `ReferenceHandlingStrategy` and observing Preserve behaviour
attach to the wrong value.

## Proposed fix
Reduce the coupling and/or guard it:
- **Guard (cheapest):** add a unit test asserting each enum member's integer value equals the literal the extractor
  assumes (a single source of truth for the mapping).
- **Decouple (better):** define shared internal `const int` values (or read the enum member symbolically from the
  `TypedConstant` where feasible) so the extractor and the public enum reference the same named constants.

## Regression test
```csharp
[Fact]
public void Strategy_enum_values_match_extractor_assumptions()
{
    Assert.Equal(1, (int)ReferenceHandlingStrategy.Preserve);
    Assert.Equal(1, (int)OnCycleStrategy.SetNull);
    Assert.Equal(1, (int)NameConvention.Flexible);
    Assert.Equal(1, (int)RequiredMappingStrategy.Both);
    // ...one assertion per magic-int the extractor relies on
}
```
Passes today; **fails immediately** if anyone reorders an enum — turning a silent desync into a loud test failure.
