# [ISSUE-032] Fuzzer avoids 0/negative/boundary numerics and empty/large collections

| | |
|---|---|
| **Severity** | Medium (test blind spot) |
| **Type** | Test infrastructure — coverage gap |
| **Component** | Testing / ObjectFactoryV2 |
| **Finding ID** | B18-1 |
| **Affects** | `src/DwarfMapper.Testing/ObjectFactoryV2.cs` |

## Where
`ObjectFactoryV2.cs:54-83` (scalar generation) and `:96` (collection size).

```csharp
if (type == typeof(int))  return rng.Next(1, int.MaxValue);   // never 0, never negative, never MinValue/MaxValue
if (type == typeof(byte)) return (byte)rng.Next(1, 256);      // never 0
if (type == typeof(sbyte))return (sbyte)rng.Next(1, 127);     // never 0, never negative, never -128
// long has a 1-in-4 full-range escape (lines 62-65) — the only type that hits boundaries
...
var n = depth >= DefaultMaxDepth ? 0 : rng.Next(1, 4);        // collections: 1..3 elems, empty only at depth cap
```

## What
Integer generation is `rng.Next(1, MaxValue)` for every integral type, so the fuzzer never produces **0**, **negative**
values, or **`MinValue`/`MaxValue`**. `char` is `'A'..'Z'` only; strings are never empty. Only `long` occasionally
(1-in-4) draws a full-range value to exercise the `long → int` overflow path. Collections are always 1–3 elements
(empty only at the depth cap, never large).

## Why it matters
The conversion machinery that most needs edge inputs is under-fuzzed:
- **Overflow / narrowing** (`CreateChecked`, the H4 machinery) — only `long → int` is exercised; every other narrowing
  and cross-type overflow is not.
- **Sign conversions** (signed ↔ unsigned) — need negative inputs, which are never generated (except `long`'s 1-in-4).
- **Zero handling** — never tested.
- **Empty-collection handling** (`nullCollections` = `AsEmpty`/`AsNull`, the unknown-count array path) and **large
  collections** — barely/never tested.

A regression in boundary narrowing, sign handling, or empty-collection mapping could pass the green suite.

## Reproduction
Static (read the cited lines). Observable by sampling `Create(typeof(int), …)` over many seeds and confirming the range
is `[1, int.MaxValue)`.

## Proposed fix
Bias the generator to include edge values with some probability, for **every** numeric type (not just `long`):

```csharp
private static T EdgeOr<T>(Random rng, Func<T> normal, params T[] edges) =>
    rng.NextDouble() < EdgeProbability ? edges[rng.Next(edges.Length)] : normal();

if (type == typeof(int))
    return EdgeOr(rng, () => rng.Next(int.MinValue, int.MaxValue),
                  0, int.MinValue, int.MaxValue, -1, 1);
// analogous for sbyte/short/…/uint/ulong, including their Min/Max and 0
```
Also draw collection sizes from `{0, 1, small, large}` occasionally (not only 1–3), and generate empty and
whitespace strings.

## Regression test
```csharp
[Theory]
[InlineData(typeof(int))]
[InlineData(typeof(sbyte))]
[InlineData(typeof(long))]
public void Factory_covers_zero_and_boundaries_over_many_seeds(Type t)
{
    var vals = Enumerable.Range(0, 500)
        .Select(seed => ObjectFactoryV2.Create(t, new Random(seed), 0)!)
        .ToHashSet();
    Assert.Contains(Convert.ChangeType(0, t), vals);            // zero appears
    Assert.Contains(t.GetField("MaxValue")!.GetValue(null)!, vals); // MaxValue appears
    // negatives for signed types, MinValue, etc.
}

[Fact]
public void Factory_produces_empty_and_large_collections()
{
    // over many seeds, sizes 0 and >(some threshold) both occur
}
```
Fails on current code (range never includes 0/Min/Max); passes after the fix.

## Notes
- Part of the test-infrastructure blind-spot trio (ISSUE-030, ISSUE-031, ISSUE-032).
- The author already added the `long → int` 1-in-4 escape (lines 62-65) — extend that instinct to all types and to
  collection sizes.
- After broadening the distribution, re-run the fuzz suite; new failures are latent bugs to file separately.
