# [ISSUE-031] Fuzzer never generates `null` for nullable types → null-handling machinery is unfuzzed

| | |
|---|---|
| **Severity** | High (test blind spot) |
| **Type** | Test infrastructure — coverage gap |
| **Component** | Testing / ObjectFactoryV2 |
| **Finding ID** | B18-2 |
| **Affects** | `src/DwarfMapper.Testing/ObjectFactoryV2.cs` |

## Where
`ObjectFactoryV2.cs:46-48`:

```csharp
var underlying = Nullable.GetUnderlyingType(type);
if (underlying is not null)
    return Create(underlying, rng, depth);   // <-- always returns a VALUE, never null
```
Reference types are also never returned as `null` (the factory constructs an instance).

## What
The fuzz input generator, given `Nullable<T>` (`int?`, `DateTime?`, …), unwraps to `T` and always produces a concrete
value. It **never** emits `null`. Consequently the property/combinatorial fuzz suites drive the mapper only with
fully-populated inputs.

## Why it matters
Null-handling is one of the largest and most subtle parts of the engine, and **none of it is exercised with actual
nulls** by fuzzing:
- `NullStrategy` (Throw / SetDefault),
- `NullSubstitute` and the `DWARF049` guard,
- nullable-source → non-nullable-target (`DWARF070`, the `!`/null-ref paths),
- `SkipNullSourceMembers`,
- `nullAsNull` collection behaviour,
- null-propagation in synthesized nested-object helpers.

A regression in any of these could pass the green suite. This is the highest-value test gap found: null-handling is
exactly where hard-to-spot mapping bugs live.

## Reproduction
Static (read the cited lines). Observable: instrument `Create` and confirm no `null` is ever produced across a fuzz run.

## Proposed fix
Give the generator a tunable null probability:

```csharp
// Nullable<T>: sometimes null.
if (underlying is not null)
    return rng.NextDouble() < NullProbability ? null : Create(underlying, rng, depth);

// Reference types: sometimes null (at non-root, to keep roots constructible).
if (!type.IsValueType && depth > 0 && rng.NextDouble() < NullProbability)
    return null;
```
Expose `NullProbability` (default e.g. 0.15) so seeded/deterministic fuzz runs remain reproducible. Ensure the oracle
already treats `null == null` and `null != value` correctly (it does — `GraphOracleComparer.cs:435-440`,
`StructuralComparer.cs:12-15`).

## Regression test
Two parts. (1) Meta-test the generator emits nulls; (2) add explicit null-handling property tests now enabled:

```csharp
[Fact]
public void Factory_produces_null_for_nullable_over_many_seeds()
{
    var sawNull = Enumerable.Range(0, 200)
        .Any(seed => ObjectFactoryV2.Create(typeof(int?), new Random(seed), 0) is null);
    Assert.True(sawNull);
}

[Fact]
public void Fuzz_null_source_members_round_trip_under_each_NullStrategy()
{
    // With nulls now generated, assert Throw vs SetDefault behave per spec across the corpus.
}
```
The first fails on current code (never null) and passes after the fix; the second becomes meaningful once nulls flow.

## Notes
- Part of the test-infrastructure blind-spot trio (ISSUE-030, ISSUE-031, ISSUE-032).
- After enabling nulls, re-run the full fuzz suite: any *new* failures are pre-existing latent bugs this gap was hiding,
  and should be filed separately.
