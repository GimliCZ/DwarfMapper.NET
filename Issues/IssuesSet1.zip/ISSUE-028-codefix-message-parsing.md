# [ISSUE-028] Code fixes recover structured data by parsing diagnostic messages

| | |
|---|---|
| **Severity** | Low |
| **Type** | Latent fragility |
| **Component** | CodeFixes (all three providers) |
| **Finding ID** | B19-1 |
| **Affects** | `src/DwarfMapper.CodeFixes/*.cs`, `src/DwarfMapper.Generator/Diagnostics/DiagnosticInfo.cs` |

## Where
- `AddMapIgnoreCodeFixProvider.cs:68-78` and `ResolveExplicitOnlyMemberCodeFixProvider.cs:87-98` — `ExtractMemberName`
  pulls the member name from the first single-quoted substring of `diagnostic.GetMessage(InvariantCulture)`.
- `AddReverseMapInverseCodeFixProvider.cs:86-96` — string-manipulates the type syntax.
- Root cause: `DiagnosticInfo` carries no `Diagnostic.Properties` (grep confirms none in `Diagnostics/`).

## What
The code fixes reverse-engineer the data they need (member name, type name) from the human-readable diagnostic message,
because the diagnostics do not carry structured properties.

## Why it matters
Works today only because messages are stable and InvariantCulture-fixed. **Any descriptor rewording silently breaks the
fix** (it would extract the wrong token or none), and nothing tests the message↔parser contract. Fragile coupling
across the diagnostics→codefix boundary. (No mapper correctness impact — IDE convenience only.)

## Reproduction
Reword a fixable descriptor's message so the member name is no longer the first quoted token; the corresponding quick
fix stops working, with no test failure.

## Proposed fix
Thread structured data via `Diagnostic.Properties`:
1. Extend `DiagnosticInfo` to carry an optional `ImmutableDictionary<string,string?> Properties` (kept value-equatable
   for the incremental cache — an `EquatableArray<KeyValuePair<string,string?>>` or similar).
2. Set `Properties["Member"] = name` where these diagnostics are created.
3. In the fixes, read `diagnostic.Properties["Member"]` instead of parsing the message.

## Regression test
```csharp
[Fact]
public void CodeFix_reads_member_from_diagnostic_properties_not_message()
{
    var diag = /* produce DWARF072 for member 'Foo' */;
    Assert.Equal("Foo", diag.Properties["Member"]);      // structured, not parsed
    // and a message-independence test: reword the message, assert the fix still targets 'Foo'.
}
```
Fails today (no `Properties`); passes after threading structured data.

## Notes
- Also add a guard test for `AddReverseMapInverse`'s unchecked `(ClassDeclarationSyntax)forward.Parent!` /
  `Parameters[0]` (finding B19-N): pattern-match instead of cast/index so a precondition drift degrades gracefully.
