# [ISSUE-009] `[MapTo]` registry ignores accessor accessibility → CS error on private get/set members

| | |
|---|---|
| **Severity** | Low |
| **Type** | Loud codegen gap |
| **Component** | Generator / `[MapTo]` Registry |
| **Finding ID** | B07-3 |
| **Affects** | `src/DwarfMapper.Generator/Registry/MapToGenerator.cs` |

## Where
`MapToGenerator.cs:200-219` (`ReadableMembers`/`WritableMembers`) — they gate on the **property's** accessibility but
not the **accessor's** (`GetMethod`/`SetMethod` `DeclaredAccessibility`).

## What
A `public int X { private get; set; }` is treated as readable, and `public int X { get; private set; }` as writable, so
the registry emits `source.X` / `X = ...` against an inaccessible accessor → CS error. Init-only setters are also treated
as plain-writable (fine for the initializer form, but untested).

## Why it matters
Legal member shapes produce a raw compile error from the generated registry extension. The main engine handles this
correctly (`MapperExtractor.ReadableMembers`/`WritableMembers` use `AccessorUsable` → `IsMemberReachable`); the registry
is the inconsistent, less-careful engine.

## Reproduction
```csharp
public class S { public int X { get; private set; } = 1; } // get is public
public class D { public int X { get; set; } }
[MapTo(typeof(D))] public partial class S2 { }
```
Reverse the accessibility on the *source* getter for the read case.

## Proposed fix
Check accessor accessibility, mirroring the main engine:
```csharp
if (m is IPropertySymbol { IsIndexer: false } p &&
    p.GetMethod is { DeclaredAccessibility: Accessibility.Public } && !p.GetMethod.IsStatic)
    yield return (p, p.Type);
```
Apply symmetrically for setters (and consider `IsInitOnly`). Ideally, share the `AccessorUsable` helper with the main
engine.

## Regression test
```csharp
[Fact]
public void MapTo_registry_skips_inaccessible_accessors()
{
    var errors = GeneratorTestHarness.RunAndGetCompilationErrors(privateAccessorSrc);
    Assert.DoesNotContain(errors, e => e.Id.StartsWith("CS")); // registry either skips or diagnoses, never emits bad access
}
```
Fails today; passes after the fix.
