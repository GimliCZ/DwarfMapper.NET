# [ISSUE-010] `[MapTo]` with two same-named targets emits duplicate `To{Name}` extensions → CS0111

| | |
|---|---|
| **Severity** | Low |
| **Type** | Loud codegen gap |
| **Component** | Generator / `[MapTo]` Registry |
| **Finding ID** | B07-4 |
| **Affects** | `src/DwarfMapper.Generator/Registry/MapToGenerator.cs` |

## Where
`MapToGenerator.cs:154,296-300` — the per-target extension method is named `"To" + target.Name` (simple name).

## What
Two `[MapTo]` targets with the same simple type name but different namespaces (e.g. `A.Foo` and `B.Foo`) both produce a
`To Foo(this Source)` extension → CS0111 ("type already defines a member called 'ToFoo' with the same parameter types").
No collision guard.

## Why it matters
Legal input → raw CS0111 from generated code. The class-model aggregate facade guards its analogue via DWARF058; the
registry has no equivalent.

## Reproduction
```csharp
[MapTo(typeof(A.Foo), typeof(B.Foo))]   // both simple-named Foo
public partial class Src { }
```

## Proposed fix
Detect simple-name collisions among a source's `[MapTo]` targets; either (a) emit a registry diagnostic
(`DWARFR0x DuplicateToExtension`) instructing the user to disambiguate, or (b) qualify the method name on collision
(e.g. `ToFoo` vs `ToBFoo`). Prefer (a) for clarity (mirrors DWARF058).

## Regression test
```csharp
[Fact]
public void MapTo_same_named_targets_do_not_emit_duplicate_extensions()
{
    var errors = GeneratorTestHarness.RunAndGetCompilationErrors(twoFooTargetsSrc);
    Assert.DoesNotContain(errors, e => e.Id == "CS0111");
}
```
Fails today; passes after the fix.
