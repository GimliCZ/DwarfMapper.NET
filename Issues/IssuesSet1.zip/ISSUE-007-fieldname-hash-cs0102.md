# [ISSUE-007] Aggregate `FieldName` mangling can collide → CS0102 duplicate field

| | |
|---|---|
| **Severity** | Medium |
| **Type** | Loud codegen gap (legal input → raw compile error) |
| **Component** | Generator / AggregateEmitter |
| **Finding ID** | B06-1 |
| **Affects** | `src/DwarfMapper.Generator/Pipeline/AggregateEmitter.cs` |

## Where
`AggregateEmitter.cs:343-349` (`FieldName`): builds a cached-singleton field name as `"__" + name.Replace('.', '_')`
with no disambiguator.

## What
Two distinct fully-qualified type names that differ only by a character that maps to `_` under the transform collapse
to the same field name. e.g. `A.B` and `A_B` both become `__A_B`; `A.B.C` and `A.B_C` collide. When two mappers'
generated singleton fields mangle to the same identifier, the generated aggregate type declares the same field twice →
**CS0102** ("type already contains a definition for '__A_B'").

## Why it matters
A legal combination of type names produces a raw CS0102 from generated code with no DwarfMapper diagnostic. Rare, but
reachable and untested, and the failure is opaque (points into generated source).

## Reproduction
Two mapper source types whose FQNs collide under `Replace('.', '_')` — e.g. a type `A.B` (namespace `A`, type `B`) and
a type named `A_B` in the global namespace — both mapped in the same assembly, both contributing a cached singleton.

## Proposed fix
Make the field name collision-free. Simplest: append a short stable hash of the *original* FQN:

```csharp
static string FieldName(string fqn) =>
    "__" + SanitizeIdentifier(fqn) + "_" + Fnv1a(fqn).ToString("x8");
```
(Reuse the project's existing FNV helper — see ISSUE-015 about unifying the two FNV copies.) Alternatively, maintain a
per-emit `HashSet<string>` and suffix a counter on collision. The hash approach is deterministic and order-independent.

## Regression test
```csharp
[Fact]
public void Aggregate_field_names_do_not_collide_for_ambiguous_fqns()
{
    // Two mapper sources whose FQNs collapse to the same Replace('.','_') identifier.
    var errors = GeneratorTestHarness.RunAndGetCompilationErrors(twoCollidingMappersSrc);
    Assert.DoesNotContain(errors, e => e.Id == "CS0102");
}
```
Fails today; passes after the fix.

## Notes
- Low probability but zero-cost to fix and eliminates an entire class of opaque CS0102s.
