# [ISSUE-025] Async-stream map: no `CancellationToken` and no `ConfigureAwait(false)`

| | |
|---|---|
| **Severity** | Medium |
| **Type** | API correctness (async best practices) |
| **Component** | Generator / MapEmitter + Extractor |
| **Finding IDs** | B05-1, B05-2 |
| **Affects** | `src/DwarfMapper.Generator/Pipeline/MapEmitter.cs`, `MapperExtractor.cs` |

## Where
- **B05-1** `MapEmitter.cs:621-640` (async iterator emission) and `MapperExtractor.cs:392-423` (async-stream shape
  detection) — the generated `IAsyncEnumerable<D> Map(IAsyncEnumerable<S> src)` iterator has **no**
  `CancellationToken` parameter and no `[EnumeratorCancellation]`.
- **B05-2** same emitted body — the `await foreach` does **not** use `ConfigureAwait(false)`.

## What
For an async streaming map (`IAsyncEnumerable<D> Map(IAsyncEnumerable<S> src)`), the generator emits an async iterator
that:
1. cannot be cancelled — there is no token threaded to the `await foreach`, and no `[EnumeratorCancellation]`
   parameter to receive one from `WithCancellation(...)`; and
2. awaits without `ConfigureAwait(false)`, so it captures the synchronization context.

## Why it matters
- **Cancellation**: a long/infinite source stream cannot be cooperatively cancelled — a correctness/robustness problem
  for streaming pipelines and a deviation from `IAsyncEnumerable` conventions (analyzer CA2016 / the
  `[EnumeratorCancellation]` pattern).
- **ConfigureAwait**: in library code, not using `ConfigureAwait(false)` risks context-capture deadlocks and overhead in
  hosts with a synchronization context (classic library async guidance; analyzer CA2007).

Both are two-layer: the model/extractor must allow/carry a token parameter, and the emitter must thread it.

## Reproduction
```csharp
[DwarfMapper]
public partial class M {
    public partial IAsyncEnumerable<Dto> Map(IAsyncEnumerable<Entity> src);
}
```
Inspect the generated iterator: no token, no `ConfigureAwait(false)`.

## Proposed fix
1. Accept an optional `CancellationToken` on the user's partial signature; emit the implementation with a
   `[System.Runtime.CompilerServices.EnumeratorCancellation] CancellationToken ct = default` parameter (or honour one
   the user declares), and pass it to `source.WithCancellation(ct)` in the `await foreach`.
2. Emit `await foreach (var item in source.WithCancellation(ct).ConfigureAwait(false))`.
3. Update the extractor's async-stream detection to permit the extra `CancellationToken` parameter and record it on the
   `MapMethodModel`.

## Regression test
```csharp
[Fact]
public void Async_stream_map_threads_cancellation_and_configureawait()
{
    var (_, gen) = GeneratorTestHarness.Run(asyncStreamMapperSrc);
    Assert.Contains("[global::System.Runtime.CompilerServices.EnumeratorCancellation]", gen);
    Assert.Contains("WithCancellation(", gen);
    Assert.Contains("ConfigureAwait(false)", gen);
}

[Fact]
public async Task Async_stream_map_stops_promptly_on_cancellation()
{
    var asm = GeneratorTestHarness.EmitAssembly(asyncStreamMapperSrc);
    using var cts = new CancellationTokenSource();
    // enumerate a few, cancel, assert OperationCanceledException / prompt stop
}
```
Both fail today; pass after the fix.

## Notes
- Preserve source compatibility: users who declared no token should still compile (emit a defaulted token parameter or
  an overload).
- The extractor already honours cancellation in its *own* loops (`ct.ThrowIfCancellationRequested()`); this is about the
  *generated runtime* code, which is separate.
