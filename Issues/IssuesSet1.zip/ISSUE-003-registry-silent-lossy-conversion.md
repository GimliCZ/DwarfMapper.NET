# [ISSUE-003] `[MapTo]` registry silently accepts lossy numeric conversions (no DWARF038)

| | |
|---|---|
| **Severity** | High |
| **Type** | Correctness — silent lossy conversion |
| **Component** | Generator / `[MapTo]` Registry (`MapToGenerator.cs`) |
| **Finding ID** | B07-5 |
| **Affects** | `src/DwarfMapper.Generator/Registry/MapToGenerator.cs` |

## Where
`MapToGenerator.cs:361-362` (`Resolver.Resolve`):

```csharp
var conv = _comp.ClassifyCommonConversion(srcType, tgtType);
if (conv.IsIdentity || conv.IsImplicit) return srcExpr;   // <-- direct assign, no DWARF038 check
```

## What
The `[MapTo]` registry engine treats **any** implicit conversion as a safe direct assignment. It does **not** apply the
cross-category-lossy check that the class-model engine applies (`IsCrossCategoryNumeric` → `DWARF038`). So conversions
that are implicit in C# but **lose precision** — `long → double`, `int → float`, `long → decimal`, `int → double` for
large values — are silently emitted as `dest.X = source.Y;` with no diagnostic.

The class-model (`[DwarfMapper]`) engine warns on exactly these via `DWARF038` (escalating to an error under
`ImplicitConversions = false`) — see `MapperExtractor.cs` `IsCrossCategoryNumeric` and the DWARF038 emission.

## Why it matters
The two engines disagree on the same conversion: mapping `long → double` through a `[DwarfMapper]` class warns you it's
lossy, but the same mapping through `[MapTo]` is silent. A user who chose the lighter-weight `[MapTo]` front door loses
the precision-loss safety net without any indication. Silent precision loss in numeric mapping is a classic
hard-to-debug data bug.

## Reproduction
```csharp
public class S { public long V { get; set; } }
public class D { public double V { get; set; } }   // long -> double is implicit but lossy for |V| > 2^53

[MapTo(typeof(D))]
public partial class S2 { }   // registry front door
```
Expected: a diagnostic equivalent to `DWARF038` (lossy widening).
Actual: `D.V = source.V;` emitted silently.

Verifiable now via the harness:
```csharp
var (diags, _) = GeneratorTestHarness.RunMapTo(src);
// currently: no DWARFR/DWARF038-equivalent diagnostic
```

## Proposed fix
In `Resolver.Resolve`, before returning `srcExpr` for an implicit conversion, run the same cross-category check the
class engine uses and emit a registry-scoped diagnostic (e.g. new `DWARFR07 LossyImplicitConversion`, mirroring
`DWARF038`'s Info-default / error-under-strict behaviour). Reuse `IsCrossCategoryNumeric` by extracting it to a shared
helper both engines call (avoids the two-engine drift that produced this gap).

```csharp
if (conv.IsIdentity) return srcExpr;
if (conv.IsImplicit)
{
    if (NumericRules.IsCrossCategoryLossy(srcType, tgtType))
        _diags.Add(new DiagnosticInfo(RegistryDiagnostics.LossyImplicit, _loc, $"{srcType} -> {tgtType}"));
    return srcExpr;
}
```

## Regression test
```csharp
[Fact]
public void MapTo_registry_flags_lossy_implicit_conversion()
{
    const string src = /* S(long V) -> D(double V) via [MapTo] */;
    var (diags, _) = GeneratorTestHarness.RunMapTo(src);
    Assert.Contains(diags, d => d.Id == "DWARFR07"); // or the DWARF038-equivalent id chosen
}
```
Must fail on current code (no diagnostic) and pass after the fix. Add symmetric cases (`int→float`, `long→decimal`).

## Notes
- The `[MapTo]` registry is an acknowledged prototype-tier engine (see `RegistryDiagnostics.cs` header), so a
  registry-scoped `DWARFR` id is appropriate; the deeper fix is to **share** the numeric-safety logic between engines.
- Related two-engine-drift issues: ISSUE-009, ISSUE-010, ISSUE-011, ISSUE-020.
