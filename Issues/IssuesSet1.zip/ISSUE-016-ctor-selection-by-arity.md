# [ISSUE-016] Constructor selected by arity, not by mappability

| | |
|---|---|
| **Severity** | Medium |
| **Type** | Correctness (surprising selection; usually loud downstream) |
| **Component** | Generator / ConstructorSelector |
| **Finding ID** | B01-4 |
| **Affects** | `src/DwarfMapper.Generator/Pipeline/ConstructorSelector.cs` |

## Where
`ConstructorSelector.cs:137` — candidate constructors are ordered `OrderByDescending(c => c.Parameters.Length)` and the
first is chosen; selection is driven by **parameter count**, not by whether the parameters can actually be satisfied
from the source.

## What
When a target has multiple constructors, the selector prefers the one with the most parameters. If that
highest-arity constructor has a parameter that **cannot** be mapped from the source, the selector still picks it (rather
than falling back to a lower-arity constructor whose parameters *are* all mappable), leading to a `DWARF024`
"unmappable constructor parameter" error even though a viable constructor existed.

## Why it matters
The failure is loud (DWARF024), so it is not silent data loss — but it is a **surprising** and unnecessarily
restrictive selection: the user sees "can't map parameter X" for a constructor they didn't expect to be chosen, when a
perfectly mappable constructor was available. This hurts adoption on types with several constructors (common on records
with additional convenience ctors).

## Reproduction
```csharp
public class Target {
    public Target(int id) { ... }                       // fully mappable from Src
    public Target(int id, SomethingUnmappable x) { ... } // higher arity, x not in Src
}
public class Src { public int Id { get; set; } }

[DwarfMapper]
public partial class M { public partial Target Map(Src s); }
```
Expected: pick `Target(int id)` and succeed. Actual: pick the 2-arg ctor and emit DWARF024 for `x`.

## Proposed fix
Select the best **mappable** constructor, not merely the widest:
1. Rank candidates (e.g. by arity, or by a "coverage" score = number of parameters satisfiable from source).
2. For each candidate in rank order, attempt parameter resolution *without emitting diagnostics* (dry run).
3. Choose the first candidate whose parameters are **all** resolvable; only if none qualifies, emit DWARF024 against
   the best candidate (preserving today's loud behaviour for the genuinely-unmappable case).

Keep the existing `[DwarfMapperConstructor]` explicit override as the highest-priority selector.

## Regression test
```csharp
[Fact]
public void ConstructorSelector_prefers_a_mappable_ctor_over_a_wider_unmappable_one()
{
    var (diags, gen) = GeneratorTestHarness.Run(twoCtorTargetSrc);
    Assert.DoesNotContain(diags, d => d.Id == "DWARF024");
    Assert.Contains("new Target(", gen); // and specifically the 1-arg form
}
```
Fails today (DWARF024 raised); passes after the fix.

## Notes
- Ensure the dry-run resolution does not pollute the `synthesized` dict or emit diagnostics (use a throw-away
  diagnostics list, as the FlattenGraph leaf resolver already does at `MapperExtractor.cs:5502-5508`).
