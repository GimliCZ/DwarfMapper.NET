# [ISSUE-022] `HasDerivedTypesInCompilation` re-walks all assembly types on every call

| | |
|---|---|
| **Severity** | Medium |
| **Type** | Performance (compile-time / IDE) |
| **Component** | Generator / Extractor |
| **Finding ID** | B11-1 |
| **Affects** | `src/DwarfMapper.Generator/Pipeline/MapperExtractor.cs` |

## Where
`MapperExtractor.cs:3774-3806` (`HasDerivedTypesInCompilation` + `AllTypesIn`). Each call to
`HasDerivedTypesInCompilation` runs `AllTypesIn(compilation.Assembly.GlobalNamespace)` — a full recursive walk of every
type in the assembly — and then walks each type's base chain.

## What
The DWARF071 "auto-nested non-sealed source may drop derived members" check calls
`HasDerivedTypesInCompilation` once per candidate auto-nested object source. Each call re-enumerates **all** types in the
assembly. For a mapper with N auto-nested object pairs in an assembly of T types, the cost is O(N · T · depth), with no
memoization.

## Why it matters
Source generators run on **every keystroke** in the IDE. A full assembly type-walk repeated per auto-nested pair can add
noticeable latency on large projects, degrading the editing experience. Correctness is unaffected.

## Reproduction
Static (read the cited lines). Observable by profiling generator execution on a large assembly with several auto-nested
mappers, or via `GeneratorDriver` timing in a stress test.

## Proposed fix
Compute the base→derived relationship **once** per compilation and reuse it. Options:
- Build a `HashSet<INamedTypeSymbol>` of "types that are a base of something in this assembly" in a single
  `AllTypesIn` pass, then `HasDerivedTypesInCompilation(src)` is a set lookup; or
- Build a `Dictionary<INamedTypeSymbol, bool>` memo keyed by `OriginalDefinition` (with
  `SymbolEqualityComparer.Default`).

Thread the precomputed structure through `Extract` (it is already per-Extract-call scoped, so no caching-correctness
concern — it holds symbols but is transient, like `NestedMappingRegistry`).

## Regression test
Behaviour must be identical; guard performance with a bounded-work assertion:
```csharp
[Fact]
public void DerivedType_scan_is_computed_once_per_compilation()
{
    // Instrument AllTypesIn (e.g. an internal counter under DEBUG) and assert it runs O(1) times
    // per Extract regardless of the number of auto-nested pairs.
    var passes = GeneratorTestHarness.RunAndCountAllTypesInPasses(manyAutoNestPairsSrc);
    Assert.True(passes <= 1);
}
```
And a golden-output test confirming DWARF071 is still emitted for the same cases as before.

## Notes
- Pure internal optimization; no public behaviour change. Verify the memo does not leak across compilations (keep it
  local to the `Extract` invocation to preserve incremental-cache correctness).
