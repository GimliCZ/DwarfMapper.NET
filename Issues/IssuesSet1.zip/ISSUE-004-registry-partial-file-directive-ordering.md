# [ISSUE-004] `[MapTo]` per-member directive→target alignment is unstable across partial-type files

| | |
|---|---|
| **Severity** | Medium |
| **Type** | Non-determinism (H1) |
| **Component** | Generator / `[MapTo]` Registry (`MapToGenerator.cs`) |
| **Finding ID** | B07-2 |
| **Affects** | `src/DwarfMapper.Generator/Registry/MapToGenerator.cs` |

## Where
`MapToGenerator.cs:229` (`ParseDirectives`):

```csharp
var pos = a.ApplicationSyntaxReference?.Span.Start ?? 0;
...
ordered.Sort((x, y) => x.Pos.CompareTo(y.Pos));   // sorts by intra-tree offset
```
Consumed positionally at `MapToGenerator.cs:109`:
```csharp
var d = m.Directives.Count == 1 ? m.Directives[0] : m.Directives[ti]; // i-th directive -> i-th [MapTo] target
```

## What
A source member's `[MapProperty]`/`[MapIgnore]` directives are ordered by
`ApplicationSyntaxReference.Span.Start` — a byte offset **within a single syntax tree**. They are then aligned
**positionally** to the `[MapTo]` targets (directive `i` → target `i`). When the source type is `partial` and its
members/attributes are declared across **multiple files**, `Span.Start` values come from different trees and are not a
meaningful global order, so the directive→target alignment can be wrong or order-dependent.

## Why it matters
For a multi-target `[MapTo]` type whose per-member directives are split across partial files, the wrong directive can
bind to the wrong target, or the binding can change between builds depending on syntax-tree ordering. This is a concrete
instance of the H1 partial-type determinism concern, in a real (if prototype-tier) feature. Silent wrong-target binding
is a correctness bug; build-to-build instability defeats deterministic-build guarantees.

## Reproduction
Requires a multi-file partial source (the single-tree test harness cannot express this directly — see Notes). Sketch:

`Foo.part1.cs`
```csharp
public partial class Foo {
    [MapProperty("A1")]           // intended for target #1
    public string A { get; set; }
}
```
`Foo.part2.cs`
```csharp
[MapTo(typeof(T1), typeof(T2))]
public partial class Foo {
    [MapProperty("A2")]           // intended for target #2, on a re-declared member? or a second directive
}
```
The positional alignment of the two `[MapProperty]` directives to `T1`/`T2` depends on cross-file `Span.Start`.

## Proposed fix
Do not rely on `Span.Start` for cross-file ordering. Either:

**(a)** Order directives by a stable global key: `(syntaxTree.FilePath, Span.Start)` rather than `Span.Start` alone —
gives a deterministic order, though positional-across-files semantics remain questionable; **or (preferred)**

**(b)** Replace positional directive→target alignment with an **explicit** binding. Add an optional target selector to
the directive (e.g. `[MapProperty("A1", ForTarget = typeof(T1))]`), so alignment no longer depends on source order at
all. Fall back to "applies to all targets" when unspecified (the existing single-directive semantics).

## Regression test
Needs a **multi-tree** test harness (the current `GeneratorTestHarness.BuildCompilation` uses a single syntax tree).
Add a harness overload that accepts multiple named sources, then:

```csharp
[Fact]
public void MapTo_directive_target_alignment_is_stable_across_partial_files()
{
    var files = new[] { ("Foo.part1.cs", part1), ("Foo.part2.cs", part2) };
    var a = GeneratorTestHarness.RunMulti(files);
    var b = GeneratorTestHarness.RunMulti(files.Reverse().ToArray()); // reversed tree order
    Assert.Equal(a.GeneratedSource, b.GeneratedSource);               // deterministic regardless of tree order
}
```
Reversing tree order must not change output. (This harness also serves ISSUE-018 and the H1 method-order residual.)

## Notes
- Blocked on a multi-tree harness; bundle that harness work with ISSUE-018 (`BlittableProof`) and the top-level
  method-order H1 residual.
- The runtime map path is **not** affected (it keeps a list and emits `AmbiguousMatch`); this is registry-specific.
