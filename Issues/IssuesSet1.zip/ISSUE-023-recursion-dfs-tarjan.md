# [ISSUE-023] Recursion detection re-runs DFS per node instead of a single SCC pass

| | |
|---|---|
| **Severity** | Low |
| **Type** | Performance (compile-time) |
| **Component** | Generator (NestedMappingRegistry / Extractor cycle detection) |
| **Finding ID** | B03-4 |
| **Affects** | `src/DwarfMapper.Generator/Pipeline/*` |

## Where
`NestedMappingRegistry.CanReachSelf` and `MapperExtractor.CanReach` (`MapperExtractor.cs:6901`) — reachability is
computed by a DFS invoked **once per node** to test whether the node can reach itself.

## What
Recursion-capability analysis asks "is node X on a cycle?" for each X by running a fresh DFS from X. This is
O(V · (V + E)) overall, where a single strongly-connected-components pass (Tarjan/Kosaraju) computes all cycle members
in O(V + E).

## Why it matters
Compile-time cost, run on every keystroke in the IDE. Bounded by the mapper's method/pair count (usually small), so low
priority — but on mappers with many synthesized pairs and dense call graphs it is unnecessary quadratic work.

## Reproduction
Static (read the DFS callers) / profile generator execution on a mapper with many mutually-referencing nested pairs.

## Proposed fix
Replace the per-node DFS with a single Tarjan SCC pass over the combined call graph; a node is recursion-capable iff its
SCC has size > 1 or it has a self-edge. Compute once, then answer all `IsRecursionCapable` queries by SCC membership.

## Regression test
Behaviour-preserving; guard with equivalence + a bounded-work check:
```csharp
[Fact]
public void Recursion_capability_matches_reference_and_runs_one_pass()
{
    // 1) Assert IsRecursionCapable results equal the old per-node DFS results across a corpus of graphs.
    // 2) Instrument the SCC routine to assert it runs once per Extract (not once per node).
}
```
Correctness identical; the pass-count assertion fails on current code and passes after the SCC rewrite.
