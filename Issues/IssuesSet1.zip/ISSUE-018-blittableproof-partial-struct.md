# [ISSUE-018] `BlittableProof` compares partial structs by positional field names (H1 / determinism)

| | |
|---|---|
| **Severity** | Low |
| **Type** | Determinism (H1) |
| **Component** | Generator / BlittableProof (`[Reinterpret]` blit path) |
| **Finding ID** | B01-5 |
| **Affects** | `src/DwarfMapper.Generator/Collections/BlittableProof.cs` |

## Where
`BlittableProof.cs:40-45,69` — the blittability/equivalence proof compares struct fields **positionally** (by
declaration order / field-name sequence).

## What
For `[Reinterpret]` (reinterpret-cast of unmanaged arrays), `BlittableProof` verifies source and target structs have a
compatible layout by walking fields in order. For a **partial struct** whose fields are declared across multiple files,
the field order Roslyn reports can depend on syntax-tree ordering, so the positional comparison can be order-sensitive.

## Why it matters
`[Reinterpret]` performs an unchecked memory reinterpret; a wrong equivalence decision is more serious than for
value-copy paths. For partial structs, the proof's outcome could vary with file/tree order (H1), potentially validating
or rejecting a blit inconsistently across builds.

## Reproduction
Requires a partial unmanaged struct split across files used as a `[Reinterpret]` element type (needs the multi-tree
harness — see ISSUE-004).

## Proposed fix
Make the layout comparison order-stable and identity-based rather than positional:
- Compare by explicit layout (`StructLayout`/`FieldOffset`) where available, or
- Order fields by a stable key (metadata token, or `(FilePath, Span.Start)`) before comparison, and compare field
  **types** at matching offsets — not merely names in enumeration order.

## Regression test
Using the multi-tree harness:
```csharp
[Fact]
public void BlittableProof_is_stable_across_partial_struct_file_order()
{
    var a = GeneratorTestHarness.RunMulti(new[]{ ("s1.cs", part1), ("s2.cs", part2) });
    var b = GeneratorTestHarness.RunMulti(new[]{ ("s2.cs", part2), ("s1.cs", part1) });
    Assert.Equal(a.Diagnostics.Select(d=>d.Id), b.Diagnostics.Select(d=>d.Id)); // same blit accept/reject
    Assert.Equal(a.GeneratedSource, b.GeneratedSource);
}
```
Reversing tree order must not change the blit decision.

## Notes
- Bundle with the multi-tree harness work (ISSUE-004) and the top-level method-order H1 residual.
