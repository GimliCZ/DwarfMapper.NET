# [ISSUE-021] `[Flags]` enum string-parse allocates via `Split(',')`

| | |
|---|---|
| **Severity** | Low |
| **Type** | Performance |
| **Component** | Generator / EnumConverter |
| **Finding ID** | B01-2 |
| **Affects** | `src/DwarfMapper.Generator/Collections/EnumConverter.cs` |

## Where
`EnumConverter.cs:403` — the emitted `[Flags]` string→enum parse uses `value.Split(',')` (and trims), allocating a
`string[]` plus substrings per call.

## What
Parsing a flags enum from a comma-separated string is emitted with `Split(',')`, which allocates an array and N
substrings on every invocation.

## Why it matters
Allocation on a hot path for flags-enum string parsing. Correctness unaffected.

## Reproduction
Static (read the emitted parser) / benchmark a flags-enum string→enum mapping under `[MemoryDiagnoser]`.

## Proposed fix
Emit an allocation-free parser using `ReadOnlySpan<char>` and `MemoryExtensions.Split`/manual span slicing over the
comma separator, accumulating the underlying integral value with `|`. (Or delegate to `Enum.TryParse` where the target
framework's overload is allocation-lean.)

## Regression test
```csharp
[Fact]
public void Flags_enum_string_parse_is_allocation_free()
{
    var asm = GeneratorTestHarness.EmitAssembly(flagsParseSrc);
    var before = GC.GetAllocatedBytesForCurrentThread();
    for (int i = 0; i < 100; i++) _ = InvokeParse(asm, "A, B, C");
    var perCall = (GC.GetAllocatedBytesForCurrentThread() - before) / 100;
    Assert.True(perCall < 64, $"~{perCall} bytes/call");
}
```
Fails today (Split allocates); passes after the span rewrite.
