# [ISSUE-013] Replace display-string type/attribute matching with symbol comparison

| | |
|---|---|
| **Severity** | Medium |
| **Type** | Consistency / robustness |
| **Component** | Generator (multiple) |
| **Finding IDs** | B01-1, B06-3, B11-2 |
| **Affects** | scalar converters, `AggregateEmitter.cs`, `MapperExtractor.cs` |

## Where
Several sites identify a type/interface by comparing `ToDisplayString()` to a literal string, instead of comparing
symbols:
- **B01-1** — scalar converter matches `IFormattable` by its display string (its sibling `IParsable` uses robust symbol
  matching).
- **B06-3** — `AggregateEmitter.cs` matches generic `[UsesMap]` by a display string that **includes the type-parameter
  names**, so it breaks if the user names their type parameters differently.
- **B11-2** — `MapperExtractor.cs:3855` matches `IEnumerable<T>` via
  `iface.OriginalDefinition.ToDisplayString() == "System.Collections.Generic.IEnumerable<T>"`, while the sibling
  `IsUnsupportedCollectionTarget` (`:3884`) correctly uses `SpecialType.System_Collections_Generic_IEnumerable_T`.

## What
Display-string comparison is fragile: it depends on formatting details (type-parameter names, nullable annotations,
global:: prefixes, tuple element names) that are not part of type identity. Two of the three sites already have a
**sibling** doing it the robust way (symbol / `SpecialType`), so the codebase is internally inconsistent.

## Why it matters
- **B06-3** is a genuine functional risk: `[UsesMap<TSource, TTarget>]` matched by a string containing `TSource`/
  `TTarget` fails to match when the user writes `[UsesMap<S, T>]`.
- **B01-1 / B11-2** are lower-risk (BCL types with fixed names) but are latent fragilities and inconsistencies that
  invite future breakage.

## Reproduction
For B06-3:
```csharp
[UsesMap<Src, Dst>]     // type params named Src/Dst, not the expected TSource/TTarget
public partial class M { ... }
```
The `[UsesMap]` is silently not recognized because the display string differs.

## Proposed fix
Match by symbol, not string:
- Resolve the well-known type once via `compilation.GetTypeByMetadataName(...)` and compare with
  `SymbolEqualityComparer.Default` (or compare `OriginalDefinition`), OR use `SpecialType` for BCL types.
- For `IEnumerable<T>` (B11-2): use `SpecialType.System_Collections_Generic_IEnumerable_T` (copy the sibling at
  `:3884`).
- For `[UsesMap<,>]` (B06-3): match `AttributeClass.OriginalDefinition` against the resolved attribute symbol +
  arity + namespace, not its display string.

## Regression test
```csharp
[Fact]
public void UsesMap_matches_regardless_of_type_parameter_names()
{
    var (diags, gen) = GeneratorTestHarness.Run(usesMapWithCustomTypeParamNames);
    // Assert the ambient-map requirement was recorded (e.g. the DwarfRequiresMap attribute is emitted).
    Assert.Contains("DwarfRequiresMap", gen);
}

[Fact]
public void IEnumerable_detection_uses_SpecialType()
{
    // A type implementing IEnumerable<T> via an unusual formatting path is still detected as a collection.
}
```
B06-3 test fails today (custom type-param names not matched) and passes after the fix.

## Notes
- Grep guard to prevent regressions: a unit test asserting no `AttributeClass?.ToDisplayString() ==` /
  `OriginalDefinition.ToDisplayString() ==` remains for *type identity* purposes (display strings are fine for
  diagnostic *messages*).
- The non-generic FQN sites (e.g. `KnownNames.MapPropertyFqn`) are acceptable (no type params to drift) and out of
  scope here; see ISSUE-014 for the namespace-gate variant.
