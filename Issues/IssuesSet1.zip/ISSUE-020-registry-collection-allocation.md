# [ISSUE-020] `[MapTo]` registry collection helper: List→ToArray double-alloc, no pre-sizing

| | |
|---|---|
| **Severity** | Low |
| **Type** | Performance |
| **Component** | Generator / `[MapTo]` Registry |
| **Finding ID** | B07-7 |
| **Affects** | `src/DwarfMapper.Generator/Registry/MapToGenerator.cs` |

## Where
`MapToGenerator.cs:477-480` — the synthesized collection helper builds `new List<T>()` (default capacity) and, for array
targets, calls `.ToArray()` (second allocation + copy).

## What
Same performance shape as ISSUE-019 but in the registry engine: no capacity pre-sizing, and array targets pay a
`List`+`ToArray` double allocation.

## Why it matters
Steady-state allocation per map call for `[MapTo]` collection mappings. Correctness unaffected. Filed separately from
ISSUE-019 because it is a distinct (duplicated) code path in the prototype registry engine.

## Reproduction
Static (read the emitted helper) / observable via a benchmark of a `[MapTo]` collection mapping.

## Proposed fix
Mirror the ISSUE-019 fix in the registry helper: size from `ICollection<T>.Count` when available, fill an array
directly for array targets, and pre-size the list otherwise. Ideally share the emission with the class-model
`CollectionConverter` to end the two-engine drift.

## Regression test
```csharp
[Fact]
public void MapTo_array_mapping_allocates_single_buffer()
{
    var asm = GeneratorTestHarness.EmitAssembly(mapToListToArraySrc);
    var before = GC.GetAllocatedBytesForCurrentThread();
    _ = InvokeMapTo(asm, new List<int>(Enumerable.Range(0,1000)));
    Assert.True(GC.GetAllocatedBytesForCurrentThread() - before < 6_000);
}
```
Fails today; passes after the fix.
