# [ISSUE-030] Test oracle sorts scalar collections → list-reordering bugs are invisible to the fuzzer

| | |
|---|---|
| **Severity** | High (test blind spot) |
| **Type** | Test infrastructure — coverage gap |
| **Component** | Testing / GraphOracleComparer |
| **Finding ID** | B17-1 |
| **Affects** | `src/DwarfMapper.Testing/GraphOracleComparer.cs` |

## Where
`GraphOracleComparer.cs:583-618` (`ToSortedList`) called from the collection-compare branch at
`GraphOracleComparer.cs:514-515`:

```csharp
if (list.Count > 0 && list[0] is not null && IsScalar(list[0]!.GetType()))
    list.Sort(/* by stable string key */);   // <-- sorts ANY scalar collection before comparing
```

## What
Before comparing two collections, `ToSortedList` **sorts** them whenever the first element is scalar. This applies
**set** semantics (order-independent) to **all** scalar-element collections — including ordered `List<int>`,
`List<string>`, `int[]`, `List<enum>`. The oracle therefore cannot tell an ordered `List<T>` from an unordered
`HashSet<T>`, so it sorts both. Collections of *non-scalar* elements are **not** sorted (order is checked).

## Why it matters
This is the oracle that the fuzzing/property suites trust (`FlattenGraphFuzzTests`, `TopologyOracleFuzzTests`,
`CombinatorialEngineTests`). Because it sorts scalar lists, a generator regression that **reorders** a scalar list
during mapping would still compare **equal** — the fuzz suite would stay green. Order preservation for `List<T>` is a
reasonable mapping contract, so this is a real hole: "all tests pass" does not currently imply "scalar-list order is
preserved."

Not an active bug today (`CollectionConverter` maps element-wise in order), but it removes the safety net for that
property.

## Reproduction
Static (read the cited lines). Demonstrable by mutation: reverse the emitted collection-fill loop in
`CollectionConverter` and observe the fuzz suite still passes for scalar-list cases.

## Proposed fix
Distinguish ordered from unordered collections instead of blanket-sorting scalars:

- For arrays and `List<T>`/`IList<T>`/`IReadOnlyList<T>` targets — compare **in original order** (no sort).
- For known set/dict types (`HashSet<T>`, `ISet<T>`, `ImmutableHashSet<T>`, dictionary key sets) — compare as
  **multisets** (sorted or count-based), since their iteration order is genuinely unspecified.

Pass the declared/target collection kind into the comparer (it is known at the call site) rather than inferring from
element scalar-ness.

## Regression test
Add a meta-test for the oracle itself (guards the oracle, not the generator):

```csharp
[Fact]
public void Oracle_detects_reordered_scalar_list()
{
    var a = new List<int> { 1, 2, 3 };
    var b = new List<int> { 3, 2, 1 };
    // A List<int> is ordered: reordering IS a difference.
    Assert.False(GraphOracleComparer.ValueEqual(Wrap(a), Wrap(b)));
}

[Fact]
public void Oracle_treats_hashset_as_unordered()
{
    var a = new HashSet<int> { 1, 2, 3 };
    var b = new HashSet<int> { 3, 2, 1 };
    Assert.True(GraphOracleComparer.ValueEqual(Wrap(a), Wrap(b)));
}
```
The first test fails on current code (oracle sorts the list) and passes after the fix; the second must stay green.

## Notes
- Part of the "test-infrastructure blind spot" trio (with ISSUE-031, ISSUE-032). Individually low-drama; together they
  bound what the green suite guarantees.
- `StructuralComparer` shares scalar-comparison logic — verify it does not have the same blanket-sort (and fix if so).
