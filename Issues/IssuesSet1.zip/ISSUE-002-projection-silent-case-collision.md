# [ISSUE-002] IQueryable projection silently first-picks on a case-insensitive member collision

| | |
|---|---|
| **Severity** | High |
| **Type** | Correctness (silent) + non-determinism (H1) |
| **Component** | Generator / Projection (`MapperExtractor.cs`) |
| **Finding ID** | B13-1 |
| **Affects** | `src/DwarfMapper.Generator/Pipeline/MapperExtractor.cs` |

## Where
Three sites — the projection resolvers:
- `MapperExtractor.cs:6310-6312` (`ResolveProjectionMembers`)
- `MapperExtractor.cs:6754-6756` (`ResolveProjectionNestedObjectExpr`)
- `MapperExtractor.cs:6861-6863` (`ResolveProjectionCtorExpr`)

```csharp
var sources = ReadableMembers(sourceType)
    .GroupBy(m => m.Name, comparer)                 // comparer = OrdinalIgnoreCase when CaseInsensitive
    .ToDictionary(g => g.Key, g => g.First(), comparer);   // <-- silent first-pick
```

## What
The projection resolvers build their source-member lookup by grouping on member name with `comparer` and then taking
`g.First()`. `ReadableMembers` de-duplicates by **Ordinal** name, so when the mapper is configured
`CaseInsensitive = true`, two members differing only in case (e.g. `Foo` and `foo`) are **both** yielded, grouped into
one bucket, and `g.First()` **silently selects one** — with no ambiguity diagnostic anywhere in the projection path
(`6303-6900` contains no `Ambiguous`/`count > 1` check).

The runtime map path does the **same** grouping (`MapperExtractor.cs:2296-2302`) but keeps a **list** and emits
`AmbiguousMatch` / `AmbiguousNormalizedMatch` when `count > 1`.

## Why it matters
1. **Silent** — a real ambiguity is resolved without telling the user (violates "loud, never silent").
2. **Inconsistent** — the same input is a loud error via `.Map(...)` at runtime but silently "works" via
   `.MapProjection(IQueryable<...>)`. Behaviour depends on which API you call.
3. **Non-deterministic (H1)** — which member wins is the order `ReadableMembers` yields them, which for a **partial
   source type split across files** depends on `GetMembers()` cross-file ordering. Two builds of the same source can
   pick different members and generate different SQL/expression trees.

## Reproduction
```csharp
public class Src { public int Foo { get; set; } public int foo { get; set; } } // legal: distinct symbols
public class Dst { public int Foo { get; set; } }

[DwarfMapper(CaseInsensitive = true)]
public partial class M {
    public partial IQueryable<Dst> Project(IQueryable<Src> q);
}
```
Expected: `AmbiguousMatch` (as the runtime `Dst Map(Src)` path already produces).
Actual: no diagnostic; `Dst.Foo` is silently bound to whichever of `Src.Foo`/`Src.foo` is enumerated first.

## Proposed fix
Mirror the runtime path exactly. Keep the group as a list and emit the ambiguity diagnostic instead of `First()`:

```csharp
var groups = ReadableMembers(sourceType).GroupBy(m => m.Name, comparer);
var sources = new Dictionary<string, MemberInfoLike>(comparer);
foreach (var g in groups)
{
    var members = g.ToList();
    if (members.Count > 1)
    {
        diagnostics.Add(new DiagnosticInfo(DiagnosticDescriptors.AmbiguousMatch, location, g.Key));
        continue; // do not bind an ambiguous member
    }
    sources[g.Key] = members[0];
}
```
Apply to all three resolvers (factor into a shared helper to avoid drift). This also removes the H1 order-dependence
(an ambiguous group never silently resolves, regardless of enumeration order).

## Regression test
```csharp
[Fact]
public void Projection_case_insensitive_member_collision_is_ambiguous_not_silent()
{
    const string src = /* the Src/Dst/[DwarfMapper(CaseInsensitive=true)] projection source above */;
    var (diags, _) = GeneratorTestHarness.Run(src);
    Assert.Contains(diags, d => d.Id == "DWARF0xx-AmbiguousMatch");
}

[Fact]
public void Projection_and_runtime_paths_agree_on_ambiguity()
{
    // Same source declares BOTH `IQueryable<Dst> Project(IQueryable<Src>)` and `Dst Map(Src)`.
    // Assert both raise the ambiguity diagnostic (currently only the runtime one does).
}
```
Both must fail on current code (no diagnostic from the projection path) and pass after the fix.

## Notes
- One of the two confirmed **H1** instances in real code (the other is ISSUE-004, the registry).
- Replicated across all three projection resolvers — fix all three, ideally via one shared helper.
