# [ISSUE-006] Mapper nested inside a `record`/`record struct`/`interface` emits mismatched partial → CS0261

| | |
|---|---|
| **Severity** | Medium |
| **Type** | Loud codegen gap (legal input → raw compile error) |
| **Component** | Generator / Extractor |
| **Finding ID** | B09-1 |
| **Affects** | `src/DwarfMapper.Generator/Pipeline/MapperExtractor.cs` |

## Where
`MapperExtractor.cs:2230` (`ContainingTypeDeclarations`):

```csharp
var keyword = outer.TypeKind == TypeKind.Struct ? "struct" : "class";
chain.Add($"{accessibility} partial {keyword} {outer.Name}");
```

## What
When emitting the chain of containing-type headers the generated partial must reproduce, the keyword is only ever
`struct` or `class`. There is no case for `record`, `record struct`, or `interface`. A `[DwarfMapper]` class nested
inside a `record Outer` therefore emits `partial class Outer`, which the compiler rejects with **CS0261** ("partial
declarations of 'Outer' must be all classes, all record classes, …"). Same for `record struct` (emits `partial struct`)
and `interface` (emits `partial class`).

## Why it matters
Nesting a mapper inside a record is ordinary (records are common DTO/aggregate carriers). The user gets a raw CS0261
from generated code instead of a DwarfMapper diagnostic — confusing and hard to trace. Confirmed unguarded and untested
(all other `record` handling in the extractor concerns record *targets/sources*, not containers).

## Reproduction
```csharp
public partial record Outer            // record container
{
    [DwarfMapper]
    public partial class M
    {
        public partial Dto Map(Entity e);
    }
}
```
Result: CS0261 on `Outer`.

## Proposed fix
Emit the correct kind based on the containing type:

```csharp
string keyword =
    outer.IsRecord && outer.TypeKind == TypeKind.Struct ? "record struct" :
    outer.IsRecord                                      ? "record" :
    outer.TypeKind == TypeKind.Struct                   ? "struct" :
    outer.TypeKind == TypeKind.Interface                ? "interface" :
                                                          "class";
```
(Interfaces can legally contain nested types in modern C#; verify the mapper-in-interface scenario end-to-end.)

## Regression test
```csharp
[Theory]
[InlineData("record")]
[InlineData("record struct")]
[InlineData("interface")]
public void Mapper_nested_in_non_class_container_compiles(string containerKind)
{
    var src = $$"""
        public partial {{containerKind}} Outer {
            [DwarfMapper] public partial class M { public partial Dto Map(Entity e); }
        }
        /* Entity, Dto defs */
        """;
    var errors = GeneratorTestHarness.RunAndGetCompilationErrors(src);
    Assert.DoesNotContain(errors, e => e.Id == "CS0261");
}
```
Fails today for all three container kinds; passes after the fix.

## Notes
- Also relevant: ensure the partial-required check (already present) works for record containers (it uses syntax
  modifiers, so it does).
