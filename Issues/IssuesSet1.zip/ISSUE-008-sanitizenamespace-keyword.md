# [ISSUE-008] `SanitizeNamespace` does not escape C# keyword segments → invalid generated namespace

| | |
|---|---|
| **Severity** | Low |
| **Type** | Loud codegen gap |
| **Component** | Generator / DwarfGenerator |
| **Finding ID** | B07-1 |
| **Affects** | `src/DwarfMapper.Generator/DwarfGenerator.cs` |

## Where
`DwarfGenerator.cs:232-247` (`SanitizeNamespace`) — maps assembly-name segments to identifiers, handling leading digits
and empty segments, but **not** C# keywords.

## What
An assembly named so that a segment is a C# keyword (e.g. `My.class`, `Foo.namespace`, `X.event`) yields
`namespace My.class;` in the generated DI class, which is a compile error (a keyword can't be a namespace identifier
without `@`).

## Why it matters
A legal assembly name produces a raw compile error from generated code. Low probability (few assemblies are named
`.class`) but reachable, and the failure is opaque.

## Reproduction
Build a project whose `AssemblyName` is `Demo.class` with any `[DwarfMapper]` present → the generated
`AddDwarfMappers` DI class emits `namespace Demo.class { ... }` → CS error.

## Proposed fix
Escape keyword segments with `@` (or a `_` prefix). Roslyn exposes `SyntaxFacts.GetKeywordKind` /
`SyntaxFacts.IsReservedKeyword`:
```csharp
if (SyntaxFacts.GetKeywordKind(s) != SyntaxKind.None || SyntaxFacts.GetContextualKeywordKind(s) != SyntaxKind.None)
    s = "@" + s;
```

## Regression test
```csharp
[Fact]
public void SanitizeNamespace_escapes_keyword_segments()
{
    var errors = GeneratorTestHarness.RunAndGetCompilationErrors(mapperSrc, assemblyName: "Demo.class");
    Assert.DoesNotContain(errors, e => e.Id.StartsWith("CS")); // no compile error from the DI namespace
}
```
Fails today; passes after the fix.
