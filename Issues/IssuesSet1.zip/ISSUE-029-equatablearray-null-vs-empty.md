# [ISSUE-029] `EquatableArray` default (null-backed) compares unequal to an empty array

| | |
|---|---|
| **Severity** | Low |
| **Type** | Performance (incremental caching) |
| **Component** | Generator / Collections / EquatableArray |
| **Finding ID** | B14-1 |
| **Affects** | `src/DwarfMapper.Generator/Collections/EquatableArray.cs` |

## Where
`EquatableArray.cs:27` (Equals) and `:45-48` (GetHashCode):
```csharp
if (_array is null || other._array is null) return _array is null && other._array is null;
...
if (_array is null) return 0;                 // null -> hash 0
var hash = 17; foreach (...) ...              // empty array -> hash 17
```

## What
A `default(EquatableArray<T>)` / null-backed instance compares **unequal** to a `From([])` empty-array instance (Equals
returns false; hash codes differ: 0 vs 17). The two "empty" representations are distinct.

## Why it matters
No incorrect output — but if two otherwise-identical models differ only in that one holds `default` and the other holds
`From([])` for the same logically-empty collection, they compare unequal and cause a **spurious incremental-cache miss**
(the downstream `SourceOutput` re-runs and re-emits identical source). Latent today because models consistently use
`EquatableArray.From(...)` (non-null), but easy to trip by adding a `default`-returning path.

## Reproduction
Static. Demonstrable:
```csharp
Assert.False(default(EquatableArray<int>).Equals(EquatableArray.From(Array.Empty<int>())));
```

## Proposed fix
Normalize null and empty to be equal (and hash-equal):
```csharp
public bool Equals(EquatableArray<T> other)
{
    var a = _array ?? Array.Empty<T>();
    var b = other._array ?? Array.Empty<T>();
    if (a.Length != b.Length) return false;
    for (int i = 0; i < a.Length; i++)
        if (!EqualityComparer<T>.Default.Equals(a[i], b[i])) return false;
    return true;
}
public override int GetHashCode()
{
    var a = _array ?? Array.Empty<T>();
    var hash = 17;
    foreach (var item in a) hash = hash * 31 + (item?.GetHashCode() ?? 0);
    return hash;   // empty and null now both hash to 17
}
```

## Regression test
```csharp
[Fact]
public void EquatableArray_default_equals_empty()
{
    Assert.True(default(EquatableArray<int>).Equals(EquatableArray.From(Array.Empty<int>())));
    Assert.Equal(default(EquatableArray<int>).GetHashCode(),
                 EquatableArray.From(Array.Empty<int>()).GetHashCode());
}
```
Fails today; passes after normalization. Consider also an incremental-caching test asserting an unrelated edit leaves a
model with an empty collection `Cached`.
