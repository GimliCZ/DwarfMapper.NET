# [ISSUE-011] `[MapTo]` target without a parameterless constructor → CS1729

| | |
|---|---|
| **Severity** | Low |
| **Type** | Loud codegen gap |
| **Component** | Generator / `[MapTo]` Registry |
| **Finding ID** | B07-6 |
| **Affects** | `src/DwarfMapper.Generator/Registry/MapToGenerator.cs` |

## Where
`MapToGenerator.cs:184-189` (`IsMappableTarget` — checks not-source, class/struct, not-abstract, but **not** for a
parameterless ctor) and `:304` (`Emit` always emits `new T { ... }`, an object initializer).

## What
If a `[MapTo]` target has only parameterized constructors, the emitted `new T { ... }` fails with CS1729 ("'T' does not
contain a constructor that takes 0 arguments"). The registry has no constructor-mapping path (unlike the class-model
engine's `ConstructorSelector`).

## Why it matters
Legal target types (ctor-only records/classes) → raw CS1729 from generated code, no DwarfMapper diagnostic.

## Reproduction
```csharp
public class D { public D(int id) { Id = id; } public int Id { get; } }
[MapTo(typeof(D))] public partial class S { public int Id { get; set; } }
```

## Proposed fix
In `IsMappableTarget` (or just before emit), require an accessible parameterless constructor; if absent, emit a registry
diagnostic (`DWARFR0x TargetNeedsParameterlessCtor`) directing the user to the `[DwarfMapper]` class model (which
supports constructor mapping). Optionally, add minimal positional-ctor support later.

## Regression test
```csharp
[Fact]
public void MapTo_ctor_only_target_is_diagnosed_not_CS1729()
{
    var (diags, _) = GeneratorTestHarness.RunMapTo(ctorOnlyTargetSrc);
    var errors = GeneratorTestHarness.RunAndGetCompilationErrors(ctorOnlyTargetSrc);
    Assert.DoesNotContain(errors, e => e.Id == "CS1729");
    Assert.Contains(diags, d => d.Id.StartsWith("DWARFR")); // loud, actionable
}
```
Fails today; passes after the fix.
