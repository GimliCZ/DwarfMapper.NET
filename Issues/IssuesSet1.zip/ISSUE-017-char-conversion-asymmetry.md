# [ISSUE-017] `char` ↔ numeric conversion asymmetry

| | |
|---|---|
| **Severity** | Low |
| **Type** | Consistency |
| **Component** | Generator / scalar converters |
| **Finding ID** | B01-3 |
| **Affects** | `src/DwarfMapper.Generator/Collections/*Converter.cs` |

## Where
Scalar conversion resolution (numeric/char handling in the converter chain; observed in iteration-0 H4 analysis).

## What
The treatment of `char` in numeric conversions is asymmetric: `int → char` is **refused** (`DWARF005`), while
`char → double` (and similar `char →` widening) is **accepted with a warning**. `char` is an integer-kind type, so the
two directions are handled by different rules.

## Why it matters
Not a data bug (both directions are loud — refuse or warn), but the asymmetry is surprising and inconsistent: a user
might reasonably expect `char`↔numeric to be treated uniformly (either both allowed as integer conversions, or both
requiring an explicit opt-in). Consistency reduces confusion and support burden.

## Reproduction
Two mappers: one mapping `int → char` (refused), one mapping `char → double` (warned). Observe the different handling.

## Proposed fix
Decide a single policy for `char`↔numeric and apply it in both directions:
- Treat `char` uniformly as its underlying `ushort` for conversion classification (so `int → char` narrows via
  `CreateChecked` like any narrowing, and `char → numeric` widens like any widening), **or**
- Require an explicit `[MapProperty(Use=...)]`/`[Reinterpret]` for any `char`↔numeric crossing in both directions.

Document the chosen rule.

## Regression test
```csharp
[Theory]
[InlineData("int",  "char")]
[InlineData("char", "double")]
public void Char_numeric_conversions_follow_one_consistent_policy(string from, string to)
{
    var (diags, _) = GeneratorTestHarness.Run(BuildScalarMapper(from, to));
    // Assert the SAME category of outcome in both directions (e.g. both allowed-with-checked, or both refused).
}
```
Encodes the chosen policy; fails on the current asymmetric behaviour.
