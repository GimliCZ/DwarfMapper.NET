# [ISSUE-012] Dead loop in nested-registry drain (`nestedLocation` always null)

| | |
|---|---|
| **Severity** | Low |
| **Type** | Cleanup / dead code |
| **Component** | Generator / Extractor |
| **Finding ID** | B08-1 |
| **Affects** | `src/DwarfMapper.Generator/Pipeline/MapperExtractor.cs` |

## Where
`MapperExtractor.cs:1186-1192`:
```csharp
LocationInfo? nestedLocation = null;
for (var mi = 0; mi < methods.Count; mi++)
    if (methods[mi].IsPartial)
        break;   // finds the first partial index, stores nothing; nestedLocation stays null
```

## What
The loop scans for the first partial method but discards the index; `nestedLocation` is never assigned. The loop has no
effect (the comment concedes "use a null location per existing contract").

## Why it matters
Pure dead code — no correctness impact, but it wastes a small amount of compile time and misleads readers into thinking a
location is computed. Leftover scaffolding.

## Reproduction
Static (read the cited lines).

## Proposed fix
Delete the loop and keep `LocationInfo? nestedLocation = null;`. **Or**, if DWARF030 anchoring was the original intent,
actually thread a real location (e.g. capture the first partial method's `LocationInfo` when building `methods`) — but
current behaviour is null-by-design, so removal is the honest fix.

## Regression test
No behavioural change → guarded by the existing suite. Optionally add a lint/analyzer or a comment test asserting no
dead loop reintroduced. Confirm the full test suite (5,405 tests) still passes after removal.
