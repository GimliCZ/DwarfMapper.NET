# [ISSUE-005] Dictionary mapping: key-collision is silent last-write-wins for mutable dicts, throws for immutable

| | |
|---|---|
| **Severity** | Medium |
| **Type** | Correctness — inconsistent collision handling |
| **Component** | Generator / DictionaryConverter |
| **Finding ID** | B03-1 |
| **Affects** | `src/DwarfMapper.Generator/Collections/DictionaryConverter.cs` |

## Where
`DictionaryConverter.cs:130-137` (emitted dictionary-fill code paths).

- Mutable target (`Dictionary<K,V>`): emitted body does `__r[k] = v;` — **last write wins silently** on a key collision.
- Immutable target (`ImmutableDictionary<K,V>`): emitted body uses `CreateRange(...)` — **throws** at runtime on a
  duplicate key.

## What
When the source→target **key** conversion is many-to-one (two distinct source keys convert to the same target key),
the two emitted code paths behave differently: the mutable path silently discards all but the last colliding entry;
the immutable path throws `ArgumentException` ("An item with the same key has already been added").

## Why it matters
Same logical input, same mapping declaration, different outcome depending only on the *target dictionary type* — one
silently loses data, the other crashes at run time. The silent branch is the more dangerous: a key-converting mapping
(e.g. `Dictionary<string,V>` with a `CaseInsensitive` or normalizing key transform) can drop entries with no signal.

## Reproduction
```csharp
public class S { public Dictionary<string, int> Map { get; set; } = new(); }
public class D { public Dictionary<string, int> Map { get; set; } = new(); }
// with a key converter that lowercases keys, source {"A":1, "a":2} collides to "a"

[DwarfMapper]
public partial class M {
    // ... configured so the key conversion is many-to-one
    public partial D Map(S s);
}
```
Mutable target: `D.Map` silently contains only `{"a":2}`. Immutable target of the same shape: throws at run time.

## Proposed fix
Make the two paths **consistent** and, ideally, **loud**. Options:

**(a)** Detect at compile time when the target key type/conversion can collapse distinct source keys (e.g. a key
converter that is non-injective, or `CaseInsensitive` key handling) and emit an Info/Warning diagnostic
(`DWARF0xx DictionaryKeyMayCollide`).

**(b)** Make runtime behaviour uniform: either both throw (emit an explicit "duplicate key" check on the mutable path
too) or both last-write-wins (use `dict[k] = v` semantics for immutable via a builder that overwrites). Throwing is
more consistent with the project's fail-loud stance; if last-write-wins is intended, document it and apply it to both.

Recommended: (a) + make both paths **throw** on collision by default, with an opt-in overwrite mode.

## Regression test
```csharp
[Fact]
public void Dictionary_key_collision_is_consistent_across_target_types()
{
    // Build a mapper whose key conversion maps "A" and "a" to the same key.
    var asmMutable   = GeneratorTestHarness.EmitAssembly(mutableTargetSrc);
    var asmImmutable = GeneratorTestHarness.EmitAssembly(immutableTargetSrc);

    // Both should behave the SAME on a colliding input — either both throw, or both keep the documented winner.
    var ex1 = Record.Exception(() => Invoke(asmMutable, collidingInput));
    var ex2 = Record.Exception(() => Invoke(asmImmutable, collidingInput));
    Assert.Equal(ex1 is null, ex2 is null); // symmetric outcome
}
```
Fails today (mutable silent, immutable throws); passes once the paths are unified.

## Notes
- Queued verification item; cheaply testable via `EmitAssembly` once a non-injective key converter is set up.
- Consider whether `CaseInsensitive` on a `Dictionary<string,V>` should imply case-insensitive **key** semantics
  (a separate design question surfaced by this finding).
