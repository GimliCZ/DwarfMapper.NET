# [ISSUE-024] Generated output mixes `Environment.NewLine` and explicit `\n` (non-deterministic across platforms)

| | |
|---|---|
| **Severity** | Medium |
| **Type** | Portability / build determinism |
| **Component** | Generator (assembly-wide, primarily MapEmitter) |
| **Finding ID** | B04-1 |
| **Affects** | `src/DwarfMapper.Generator/Pipeline/MapEmitter.cs` (and other emitters) |

## Where
`MapEmitter.cs` uses ~155 `AppendLine` calls (which emit `Environment.NewLine`) interleaved with converter/helper
bodies that contain explicit `\n` literals. The final string is handed to `spc.AddSource(...)` with **no newline
normalization**. Also present in other emitters (e.g. `AggregateEmitter`, registry).

## What
The generated source text contains a **mixture** of line endings: `AppendLine` produces `\r\n` on Windows and `\n` on
Linux/macOS, while embedded converter bodies use literal `\n`. The output therefore:
1. differs byte-for-byte **between platforms** (Windows CI vs Linux CI), and
2. is internally inconsistent (mixed CRLF/LF within one file).

## Why it matters
- **Deterministic builds**: the project sets `Deterministic=true`. Generated-source hashes / any snapshot or
  content-addressed caching will differ across platforms, undermining reproducibility.
- **Snapshot/golden tests**: the same-machine determinism fuzz tests pass (both runs use the same `Environment.NewLine`),
  so this is invisible to them — a blind spot the tests do not cover.
- Mixed line endings can also trip strict formatters/linters on the generated output.

## Reproduction
Static (read the emitter). Observable by generating on Windows and Linux and diffing the produced `.g.cs` bytes, or by
grepping generated output for both `\r\n` and lone `\n`.

## Proposed fix
Normalize newlines to a single choice (`\n` is the conventional choice for generated C#) at the emission boundary:
- Either replace `AppendLine` usage with explicit `.Append("...\n")`, **or**
- Normalize once before `AddSource`: `source = source.Replace("\r\n", "\n");` (and ensure no lone `\r`).

Do this in **every** emitter that calls `AddSource`, and add a single shared helper so new emitters can't reintroduce
the mix.

## Regression test
```csharp
[Fact]
public void Generated_output_uses_only_LF_line_endings()
{
    var (_, gen) = GeneratorTestHarness.Run(representativeMapperSrc);
    Assert.DoesNotContain("\r\n", gen);
    Assert.DoesNotContain("\r", gen);            // no lone CR either
}
```
This test is platform-independent (asserts the *content*, not the environment) — it fails today on Windows-generated
output and, after normalization, passes everywhere.

## Notes
- This is the portability counterpart the existing same-machine determinism tests cannot catch.
- Consider asserting normalization centrally (one test over several representative mappers) rather than per emitter.
