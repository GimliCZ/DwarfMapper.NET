# [ISSUE-019] CollectionConverter: double allocation for array targets + non-span fill

| | |
|---|---|
| **Severity** | Medium |
| **Type** | Performance |
| **Component** | Generator / CollectionConverter |
| **Finding IDs** | B02-1, B02-2 |
| **Affects** | `src/DwarfMapper.Generator/Collections/CollectionConverter.cs` |

## Where
- **B02-1** `CollectionConverter.cs:513,524` — for an **array** target from an unknown-count source, the emitted code
  builds a `List<T>` and then calls `.ToArray()` (two allocations + a copy).
- **B02-2** `CollectionConverter.cs:454` — the `List<T>` fill uses `foreach { list.Add(...) }` rather than pre-sizing +
  indexed/span writes.

## What
The generated collection-mapping bodies allocate more than necessary:
1. Array target, unknown source count → `List` grows (repeated re-allocation) then `ToArray` copies into a second
   buffer.
2. When the source count **is** knowable (`ICollection<T>.Count`, array `.Length`), the code still `Add`s element by
   element into a default-capacity list.

## Why it matters
Object mapping is frequently hot (per-request DTO mapping). These are steady-state allocations on every map call; the
benchmark set (vs Mapperly/Mapster/hand-written) is exactly where this shows up as GC pressure and throughput loss.
Correctness is unaffected.

## Reproduction
Static (read the emitted bodies) / observable via the `benchmarks/` project (`[MemoryDiagnoser]` allocation column for
collection-mapping benchmarks vs `Flat_Hand`).

## Proposed fix
1. **Array target, known count** — when the source exposes `Count`/`Length`, allocate the target array directly and
   fill by index; skip the `List` entirely.
2. **Array target, unknown count** — probe `source is ICollection<T> c` at runtime to size the array, else fall back to
   the list path.
3. **List fill** — when count is known, `new List<T>(capacity)` and add (or fill a span via
   `CollectionsMarshal.AsSpan` after `EnsureCapacity`); avoids re-allocation.

Emit the fast path guarded by a runtime type check so the general case still works.

## Regression test
Performance regressions are best guarded by an allocation assertion, not a timing test:
```csharp
[Fact]
public void Array_mapping_from_ICollection_allocates_single_buffer()
{
    var asm = GeneratorTestHarness.EmitAssembly(listToArraySrc);
    var before = GC.GetAllocatedBytesForCurrentThread();
    _ = InvokeMap(asm, new List<int>(Enumerable.Range(0, 1000)));
    var allocated = GC.GetAllocatedBytesForCurrentThread() - before;
    // one int[1000] ~ 4KB + small overhead; assert well under the List+ToArray (~2x) cost
    Assert.True(allocated < 6_000, $"allocated {allocated} bytes");
}
```
Also keep a golden-output test asserting the emitted body uses the array-direct path for `ICollection` sources.

## Notes
- The `[MapTo]` registry has the same shape and is filed separately as ISSUE-020 (the two-engine drift again).
- Verify AOT/trimming friendliness of any runtime type probe (`is ICollection<T>` is fine).
