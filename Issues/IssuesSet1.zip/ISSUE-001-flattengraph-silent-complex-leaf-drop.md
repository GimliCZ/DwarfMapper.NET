# [ISSUE-001] FlattenGraph silently drops complex-typed data leaves

| | |
|---|---|
| **Severity** | High |
| **Type** | Correctness — silent data loss |
| **Component** | Generator / FlattenGraph (`MapperExtractor.cs`) |
| **Finding ID** | B12-1 |
| **Affects** | `src/DwarfMapper.Generator/Pipeline/MapperExtractor.cs` |

## Where
`MapperExtractor.cs:5525-5528` (flat-node member synthesis inside the `[FlattenGraph]` resolver).

```csharp
if (GeneratedNames.IsComplexHelper(leafConv))
    // Complex synthesized helper — skip to avoid future 3-param mismatch.
    // Don't register leafThrowAwaySynth entries in main dict.
    continue;           // <-- member is dropped, NO diagnostic
```

## What
During flat-node synthesis, each **leaf** member of a graph node is resolved via `TryResolveConversion`. If the
resolved converter turns out to be a *complex* synthesized helper (`__DwarfMap_Obj_*`, `__DwarfMap_Coll_*`,
`__DwarfMap_Dict_*`) — i.e. the leaf is itself a nested object, a collection, or a dictionary — the code `continue`s
and the member is left at the DTO's default value. No diagnostic is emitted.

This is distinct from **edge** members (references to other graph nodes), which are intentionally nulled elsewhere
(`MapperExtractor.cs:5541-5547`) as documented topology degradation. The dropped members here are non-edge,
**data-bearing** leaves.

## Why it matters
It violates the library's core "loud, never silent" guarantee, in a real shipped feature. A node that carries a
data-bearing complex leaf — e.g. `List<string> Tags`, or a nested value object `Money Price` — is silently **not
flattened**; the corresponding DTO member stays at its default (`null`/empty) with no warning at compile time or
run time. This is exactly the class of silent data loss the project's design tenets forbid.

The complementary case (a leaf that is *truly unmappable*) was **explicitly** made loud by the "SF-LEAFDIAG" fix at
`MapperExtractor.cs:5510-5514` (it propagates `DWARF005`). The complex-leaf case was overlooked. The skip itself is a
workaround for an emission constraint (complex helpers may later be force-marked 3-param → CS7036), **not** a semantic
decision that these leaves should be discarded.

## Reproduction
Static (readable from the cited lines). A runtime repro:

```csharp
public class Node {
    public int Id { get; set; }
    public List<string> Tags { get; set; } = new();   // complex data leaf
    public Node? Next { get; set; }                    // topology edge
}
public class NodeDto {
    public int Id { get; set; }
    public List<string> Tags { get; set; } = new();
}

[DwarfMapper]
public partial class M {
    [FlattenGraph(nameof(Node.Next))]
    public partial List<NodeDto> Flatten(Node root);
}
```
Expected: `Tags` populated on each `NodeDto`, or a compile-time diagnostic explaining it can't be.
Actual: `Tags` is silently empty on every DTO; no diagnostic.

## Proposed fix
Two acceptable options; prefer (b):

**(a) Make it loud (minimum).** Before the `continue`, emit an Info/Warning diagnostic, e.g. a new
`DWARF0xx FlattenGraphLeafNotFlattened` with the member name and its complex type, so the user knows the leaf was
skipped and why.

**(b) Actually flatten it (preferred).** Resolve the complex leaf through the throw-away synth **and** merge the
resulting helper into the main `synthesized` dict *without* letting it be force-marked 3-param. The original MF-D
constraint is about the Preserve force-marking loop; for a flat-node leaf the helper is called with a single argument,
so tag the helper as "flat-node-owned / never-3-param" (a name-prefix set or a flag on `SynthesizedMethod`) and skip
it in the Preserve force-marking loop instead of skipping the *member*.

## Regression test
Add to the FlattenGraph tests. Assert (1) no silent drop and (2) whichever policy is chosen:

```csharp
[Fact]
public void FlattenGraph_complex_data_leaf_is_not_silently_dropped()
{
    const string src = /* the Node/NodeDto/[FlattenGraph] source above */;
    var (diags, generated) = GeneratorTestHarness.Run(src);

    // Policy (a): a diagnostic explains the skip.
    Assert.Contains(diags, d => d.Id == "DWARF0xx" && d.GetMessage().Contains("Tags"));

    // Policy (b): the leaf is actually assigned in the flat-node helper.
    // Assert.Contains("Tags =", generated);
    // (plus a runtime EmitAssembly test asserting Tags round-trips)
}
```
The test must **fail on the current code** (which emits neither the diagnostic nor the assignment) and pass after the fix.

## Notes
- Queued as the highest-priority silent-surprise found in the audit (real feature, not the prototype registry).
- Related: the SF-LEAFDIAG fix (5510-5514) is the template for the "loud" half — mirror its intent.
