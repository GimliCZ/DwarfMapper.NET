# DwarfMapper.NET — Audit Issue Register

Issues derived from the systematic adversarial audit (`audit/AUDIT-FINDINGS.md`, 20 batches, 107 files).
Each issue is self-contained and filable as-is (Where / What / Why / Reproduce / Fix / Regression test).

**Triage note.** No memory-safety, injection, or data-corruption issues were found. The engine core (runtime
map path, incremental model, runtime library) is high quality; the confirmed defects cluster in **secondary
features** (the prototype `[MapTo]` registry, FlattenGraph complex leaves, IQueryable projection) and in **test
infrastructure**. Fix order below is by risk-to-users, not by discovery order.

## Severity legend
- **High** — silent incorrectness / data loss, non-determinism in a real feature, or a test blind spot that lets such a regression pass green.
- **Medium** — a legal user input produces a raw compile error (no DwarfMapper diagnostic), a real consistency/perf/portability defect, or a documented-but-wrong behaviour.
- **Low** — cleanup, minor perf, cosmetic inconsistency, or latent fragility with no current impact.

## Register

| # | Title | Sev | Type | Component | Finding(s) |
|---|-------|-----|------|-----------|-----------|
| [001](ISSUE-001-flattengraph-silent-complex-leaf-drop.md) | FlattenGraph silently drops complex-typed data leaves | High | Correctness (silent data loss) | Generator/FlattenGraph | B12-1 |
| [002](ISSUE-002-projection-silent-case-collision.md) | IQueryable projection silently first-picks on case-insensitive collision | High | Correctness + determinism | Generator/Projection | B13-1 |
| [003](ISSUE-003-registry-silent-lossy-conversion.md) | `[MapTo]` registry silently accepts lossy numeric conversions | High | Correctness (silent) | Generator/Registry | B07-5 |
| [004](ISSUE-004-registry-partial-file-directive-ordering.md) | `[MapTo]` directive→target alignment unstable across partial files | Medium | Determinism (H1) | Generator/Registry | B07-2 |
| [005](ISSUE-005-dictionary-key-collision-asymmetry.md) | Dictionary mapping: key-collision last-write-wins vs immutable throw | Medium | Correctness (asymmetry) | Generator/DictionaryConverter | B03-1 |
| [006](ISSUE-006-mapper-nested-in-record-cs0261.md) | Mapper nested in a `record`/`interface` emits CS0261 | Medium | Loud codegen gap | Generator/Extractor | B09-1 |
| [007](ISSUE-007-fieldname-hash-cs0102.md) | Aggregate `FieldName` hash can collide → CS0102 | Medium | Loud codegen gap | Generator/AggregateEmitter | B06-1 |
| [008](ISSUE-008-sanitizenamespace-keyword.md) | `SanitizeNamespace` does not escape C# keyword segments | Low | Loud codegen gap | Generator/DwarfGenerator | B07-1 |
| [009](ISSUE-009-registry-accessor-accessibility.md) | `[MapTo]` registry ignores accessor accessibility → CS error | Low | Loud codegen gap | Generator/Registry | B07-3 |
| [010](ISSUE-010-registry-duplicate-to-name-cs0111.md) | `[MapTo]` same-named targets → duplicate `To{Name}` → CS0111 | Low | Loud codegen gap | Generator/Registry | B07-4 |
| [011](ISSUE-011-registry-no-parameterless-ctor-cs1729.md) | `[MapTo]` target without parameterless ctor → CS1729 | Low | Loud codegen gap | Generator/Registry | B07-6 |
| [012](ISSUE-012-extractor-dead-loop.md) | Dead loop in nested-registry drain | Low | Cleanup | Generator/Extractor | B08-1 |
| [013](ISSUE-013-display-string-attribute-matching.md) | Replace display-string type/attribute matching with symbol comparison | Medium | Consistency/robustness | Generator (several) | B01-1, B06-3, B11-2 |
| [014](ISSUE-014-namespace-gate-last-segment.md) | Generic attribute namespace gate matches last segment only | Low | Consistency/false-match | Generator/Extractor | B11-3 |
| [015](ISSUE-015-divergent-fnv-implementations.md) | Two divergent FNV-1a hash implementations | Low | Consistency | Generator (Dictionary/GeneratedNames) | B03-3 |
| [016](ISSUE-016-ctor-selection-by-arity.md) | Constructor selected by arity, not mappability | Medium | Correctness (loud, but surprising) | Generator/ConstructorSelector | B01-4 |
| [017](ISSUE-017-char-conversion-asymmetry.md) | `char`↔numeric conversion asymmetry | Low | Consistency | Generator/scalar converters | B01-3 |
| [018](ISSUE-018-blittableproof-partial-struct.md) | `BlittableProof` positional field-name compare (partial struct / H1) | Low | Determinism | Generator/BlittableProof | B01-5 |
| [019](ISSUE-019-collectionconverter-allocation.md) | CollectionConverter: double-alloc + non-span fill | Medium | Perf | Generator/CollectionConverter | B02-1, B02-2 |
| [020](ISSUE-020-registry-collection-allocation.md) | `[MapTo]` registry collection helper: double-alloc, no pre-size | Low | Perf | Generator/Registry | B07-7 |
| [021](ISSUE-021-flags-parse-allocation.md) | `[Flags]` string-parse allocates via `Split(',')` | Low | Perf | Generator/EnumConverter | B01-2 |
| [022](ISSUE-022-derivedtypes-memoization.md) | `HasDerivedTypesInCompilation` re-walks all types per call | Medium | Perf (compile-time) | Generator/Extractor | B11-1 |
| [023](ISSUE-023-recursion-dfs-tarjan.md) | Recursion detection re-runs DFS per node instead of one SCC pass | Low | Perf (compile-time) | Generator (registry/extractor) | B03-4 |
| [024](ISSUE-024-line-ending-normalization.md) | Mixed `Environment.NewLine`/`\n` in generated output | Medium | Portability/determinism | Generator (assembly-wide) | B04-1 |
| [025](ISSUE-025-async-stream-cancellation.md) | Async-stream map: no `CancellationToken`, no `ConfigureAwait(false)` | Medium | API correctness | Generator/MapEmitter+Extractor | B05-1, B05-2 |
| [026](ISSUE-026-facade-tsource-overload.md) | `DwarfMapperFacade.Map<TSource,TDest>` ignores `TSource` (doc mismatch) | Medium | API doc/impl mismatch | Runtime/IDwarfMapper | B15-1 |
| [027](ISSUE-027-enum-magic-int-coupling.md) | Extractor couples to enum values via magic ints | Low | Fragility | Generator/Extractor | B16-N |
| [028](ISSUE-028-codefix-message-parsing.md) | Code fixes recover data by parsing diagnostic messages | Low | Fragility | CodeFixes (all) | B19-1 |
| [029](ISSUE-029-equatablearray-null-vs-empty.md) | `EquatableArray` default ≠ empty (spurious cache miss) | Low | Perf (caching) | Generator/EquatableArray | B14-1 |
| [030](ISSUE-030-oracle-scalar-collection-order.md) | Test oracle sorts scalar collections → list-reorder bugs invisible | High | Test blind spot | Testing/GraphOracleComparer | B17-1 |
| [031](ISSUE-031-fuzzer-never-generates-null.md) | Fuzzer never generates `null` for nullable types | High | Test blind spot | Testing/ObjectFactoryV2 | B18-2 |
| [032](ISSUE-032-fuzzer-avoids-boundaries.md) | Fuzzer avoids 0/negative/boundary numerics & empty/large collections | Medium | Test blind spot | Testing/ObjectFactoryV2 | B18-1 |

## Confirmed sound (no issue — recorded for completeness)
- **H2** incremental-cache model: value-equatable, no symbol leaks (B14).
- **H3** culture-safe name matching: Ordinal/OrdinalIgnoreCase + InvariantCulture (B01/B11).
- **H4** numeric/enum conversion in the runtime engine: CreateChecked + DWARF038/005 (B10).
- **H1** on the runtime map path: loud `AmbiguousMatch`, sorted output (B10).
- **B05-4** (NullSubstitute + converter) and **B06-4** (cross-type MapConfig conflict): both loud (DWARF049/DWARF042), verified.
