# [ISSUE-014] Generic attribute namespace gate matches last segment only (`X.DwarfMapper` false-match)

| | |
|---|---|
| **Severity** | Low |
| **Type** | Consistency / latent false-match |
| **Component** | Generator / Extractor |
| **Finding ID** | B11-3 |
| **Affects** | `src/DwarfMapper.Generator/Pipeline/MapperExtractor.cs` |

## Where
`MapperExtractor.cs:5866, 5914, 5973` (generic pair-scoped readers) and the same pattern in `ExpandWrapperMaps`
(`MapperExtractor.cs:7021-7022`):
```csharp
if (ac is null || ac.Name != KnownNames.MapProperty || ac.TypeArguments.Length != 2
    || ac.ContainingNamespace?.Name != KnownNames.Ns)   // <-- .Name = LAST segment only
    continue;
```

## What
Generic attribute matching (`[MapProperty<,>]`, `[MapIgnore<>]`, `[MapValue<>]`, `[GenerateWrapperMap]`) gates on
`ContainingNamespace.Name`, which is only the **last** namespace segment. A user namespace ending in `.DwarfMapper`
(e.g. `Foo.DwarfMapper`) with a same-named generic attribute would **false-match**. The non-generic readers correctly
use the full FQN via `ToDisplayString()`, so the codebase is inconsistent.

## Why it matters
Very low probability, but a real inconsistency and a latent false-match that could bind a foreign attribute as if it
were DwarfMapper's. Worth aligning for robustness and to prevent confusing future behaviour.

## Reproduction
Define, in namespace `Foo.DwarfMapper`, a `MapPropertyAttribute<TS,TT>` and apply it to a mapper class — it would be
picked up by the pair-scoped reader.

## Proposed fix
Gate on the full namespace, matching the non-generic sites:
```csharp
|| ac.ContainingNamespace?.ToDisplayString() != KnownNames.Ns   // full path, not last segment
```
Apply to all four sites. Best: extract a single `IsDwarfMapperAttribute(ac, simpleName, arity)` helper so every site
uses identical, correct logic.

## Regression test
```csharp
[Fact]
public void Foreign_namespace_generic_attribute_is_not_matched()
{
    // A [MapProperty<,>] defined in namespace Foo.DwarfMapper must NOT be treated as DwarfMapper's.
    var (_, gen) = GeneratorTestHarness.Run(foreignDwarfMapperNamespaceSrc);
    Assert.DoesNotContain("/* pair-scoped rename applied */", gen);
}
```
Fails today (false-match); passes after the fix.
